 <!DOCTYPE html>
<html>     

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title>Detail Karyawan</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div class="content">
<h2><?php echo $title;?></h2>
<div class="data">
<table>
<tr>
<td width="30%">ID Karyawan</td>
<td><?php echo $karyawan->id_karyawan;?></td>
</tr>
<tr>
<td valign="top">Nama</td>
<td><?php echo $karyawan->nama;?></td>
</tr>
<tr>
<td valign="top">Alamat</td>
<td><?php echo $karyawan->alamat;?></td>
</tr>
<tr>
<td valign="top">Telp</td>
<td><?php echo $karyawan->phone_no;?></td>
</tr>
<tr>
<td valign="top">Tgl Lahir(dd-mm-yyyy)</td>
<td><?php echo date('d-m-Y',strtotime(
$karyawan->tgl_lahir));?></td>
</tr>
</table>
</div>
<br/>
<?php echo $link_back;?>
</div>
</body>
</html>