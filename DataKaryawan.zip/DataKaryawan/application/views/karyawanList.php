 <!DOCTYPE html>
 <html lang="en">
<head>
<meta http-equiv="Content-Type"content="text/html; charset=iso-8859-1"/>
<title>Karyawan List</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div class="content">
<h2>Daftar Karyawan</h2>
<divclass="paging"><?php echo $pagination;?></div>
<divclass="data"><?php echo $table;?></div>
<divclass="paging"><?php echo $pagination;?></div><br/>
<?php echo anchor('karyawan/add/',
'Tambah karyawan baru',array('class'=>'add'));?>
</div>
</body>
</html>

