<div class="alert alert-success">Data karyawan #<?php echo html_escape($karyawan->nama)?> berhasil dihapus!</div>
