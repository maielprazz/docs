<!DOCTYPE html>
<html>
<head>
<!-- meta http-equiv="Content-Type"content="text/html; charset=iso-8859-1"/-->
<title>Tambah Karyawan</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div class="content">
<h2><?php echo $title;?></h2>
<?php echo $message;?>
<?php echo validation_errors();?>
<?php echo form_open($action);?>
<div class="data">
<table>
<tr>
<td width="30%">ID Karyawan</td>
<td><input type="text" name="id_karyawan" disabled="disable" class="text"
value="<?php echo (isset($karyawan['id_karyawan']))?$karyawan['id_karyawan']:'';?>"/></td>
<input type="hidden" name="id_karyawan" value="<?php echo
(isset($karyawan['id_karyawan']))?$karyawan['id_karyawan']:'';?>"/>
</tr>
<tr>
<td valign="top">Nama Karyawan<span style="color:red;">*</span></td>
<td><input type="text" name="nama" class="text" value="<?php echo
(set_value('nama'))?set_value('nama'):$karyawan['nama'];?>"/>
<?php //echo form_error('nama');?></td>
</tr>
<tr>
<td valign="top">Alamat</td>
<td><input type="text" name="alamat" class="text" value="<?php echo
set_value('alamat')?set_value('alamat'):$karyawan['alamat'];?>"/>
<?php //echo form_error('alamat');?></td>
</tr>
<tr>
<td valign="top">Telp</td>
<td><input type="text" name="phone_no" class="text" value="<?php echo
set_value('phone_no')?set_value('phone_no'):$karyawan['phone_no'];?>"/>
<?php //echo form_error('phone_no');?></td>
</tr>
<tr>
<td  valign="top">Tgl Lahir (yyyy-mm-dd)</td>
<td><input type="text"name="tgl_lahir"class="text"
value="<?php echo (set_value('tgl_lahir'))?
set_value('tgl_lahir'):$karyawan['tgl_lahir'];?>"/>
<?php //echo form_error('tgl_lahir');?></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" value="Simpan"/></td>
</tr>
</table>
</div>
</form>
<br/>
<?php echo $link_back;?>
</div>
</body>
</html>