<?php

class Karyawan extends CI_Controller{
    private $limit=10;
    function __construct() {
        parent::__construct();
        #load library dan helper yang dibuthkan
        $this->load->library(array('table','form_validation'));
        $this->load->helper(array('form','url'));
        $this->load->model('karyawan_model','',TRUE);
    }
    
    function index($offset = 0, $order_column = 'id_karyawan', $order_type = 'asc') {
        if(empty($offset)) $offset=0;
        if(empty($order_column)) $order_column='id_karyawan';
        if(empty($order_type)) $order_type='asc';
        //CHECK FOR VALID COLUMN
        
        //load data pegawai
        $karyawans = $this->karyawan_model->get_paged_list($this->limit,
                $offset, $order_column,$order_type)->result();
        
        //generate pagination
        $this->load->library('pagination');
        $config['base_url']=site_url('karyawan/index/');
        $config['total_rows']= $this->karyawan_model->count_all();
        $config['per_page']=$this->limit;
        $config['uri_segment']=3;
        $this->pagination->initialize($config);
        $data['pagination']=$this->pagination->create_links();
        
        //generate table data
        $this->load->library('table');
        $this->table->set_empty("&nbsp;");
        $new_order=($order_type=='asc'?'desc':'asc');
        $this->table->set_heading('No',
        anchor('karyawan/index/'.$offset.'/nama/'.$new_order,'Nama'),
        anchor('karyawan/index/'.$offset.'/alamat/'.$new_order,'Alamat'),
        anchor('karyawan/index/'.$offset.'/phone_no/'.$new_order,'No_Telp'),
        anchor('karyawan/index/'.$offset.'/tgl_lahir/'.$new_order,'Tanggal_lahir(dd-mm-yyyy)'),        
        'Actions');

        $i=0+(int)$offset;

        foreach ($karyawans as $karyawan) {
            $this->table->add_row(++$i,
            $karyawan->nama,
            $karyawan->alamat,
            $karyawan->phone_no,        
            date('d-m-Y',strtotime($karyawan->tgl_lahir)),
            anchor('karyawan/view/'.$karyawan->id_karyawan,'view',array('class'=>'view')).' '.        
            anchor('karyawan/update/'.$karyawan->id_karyawan,'update',array('class'=>'update')).' '.
            anchor('karyawan/delete/'.$karyawan->id_karyawan,'delete',array('class'=>'delete',
            'onclick'=>"return confirm('Apakah yakin ingin dihapus?')"))        
            ); 
        }
        $data['table']=$this->table->generate();
        
        if ($this->uri->segment(3)=='delete_success')
            $data['message']='Data berhasil dihapus';
        else if ($this->uri->segment(3)=='add_success')
            $data['message']='Data berhasil ditambah';
        else
            $data['message']='';
        
        //loadview
       $this->load->view('karyawanList',$data);
    }
    
    function add() {
        //set common properties
        $data['title']='Tambah karyawan baru';
        $data['action']=site_url('karyawan/add/');
        $data['link_back']=anchor('karyawan/index/',
        'Kembali ke daftar karyawan',array('class'=>'back'));
        
        $this->_set_rules();

        //run validation
        if($this->form_validation->run()===FALSE){
            //set common properties
            $data['title']='Tambah Karyawan Baru';
            $data['message']='';
            $data['karyawan']['id_karyawan']='';
            $data['karyawan']['nama']='';
            $data['karyawan']['alamat']='';
            $data['karyawan']['phone_no']='';
            $data['karyawan']['tgl_lahir']='';
            $data['link_back']=  anchor('karyawan/index/','Lihat daftar karyawan',
                    array('class'=>'back'));
            $this->load->view('karyawanEdit',$data);
        }else{
            //save data
            $karyawan=array(
                'id_karyawan'=>$this->input->post('id_karyawan'),
                'nama'=>$this->input->post('nama'),
                'alamat'=>$this->input->post('alamat'),
                'phone_no'=>$this->input->post('phone_no'),
                'tgl_lahir'=>date('Y-m-d',strtotime($this->input->post('tgl_lahir')))
                );
            echo $karyawan;
            echo 'OKKK';
            $id_karyawan=$this->karyawan_model->save($karyawan);
            
            //set form input nama="id"
            $this->validation->id=$id_karyawan;
            redirect('karyawan/index/add_success');   
        }
    }
    
    function view($id_karyawan){    
        //set common properties
        $data['title']='Karyawan Detail';
        $data['link_back']=  anchor('karyawan/index/',
                'Lihat daftar karyawan',array('class'=>'back'));
        
        //get karyawan details
        $data['karyawan']=$this->karyawan_model->get_by_id($id_karyawan)->row();
        //load view
        $this->load->view('karyawanDetail',$data);
    }
    
    function update($id_karyawan) {
        //set common properties
        $data['title']='Update karyawan';
        $this->load->library('form_validation');
        //set validation properties
        $this->_set_rules();
        $data['action']=('karyawan/update/'.$id_karyawan);
        
        // run validation
        if ($this->form_validation->run()=== FALSE){
        $data['message']='';
        $data['karyawan']=$this->karyawan_model->get_by_id($id_karyawan)->row_array();
        $data['karyawan']['tgl_lahir']= date('Y-m-d',
        strtotime($data['karyawan']['tgl_lahir']));

        // set common properties
        $data['title']='Update karyawan';
        $data['message']='';
        } else {
        // save data
        //$id_karyawan=$this->input->post('id_karyawan');
        $karyawan= array('nama'=>$this->input->post('nama'),
                         'alamat'=>$this->input->post('alamat'),
                         'phone_no'=>$this->input->post('phone_no'),
                         'tgl_lahir'=> date('Y-m-d',
                         strtotime($this->input->post('tgl_lahir'))));
        $this->karyawan_model->update($id_karyawan,$karyawan);
        $data['karyawan']=$this->karyawan_model->get_by_id($id_karyawan)->row_array();
        
        // set user message
        $data['message']='update karyawan success';
        }
 
        $data['link_back']= anchor('karyawan/index/',
        'Lihat daftar karyawan',array('class'=>'back'));
        // load view
        $this->load->view('karyawanEdit',$data);
        }

function delete($id_karyawan){
 // delete karyawan
 $this->karyawan_model->delete($id_karyawan);
 // redirect to karyawan list page
 redirect('karyawan/index/delete_success','refresh');
 }

 // validation rules        
 function _set_rules(){

$this->form_validation->set_rules('nama','Nama',
 'required|trim');
 $this->form_validation->set_rules('tgl_lahir','Tanggal
 Lahir','required|callback_valid_date');
 }

 // date_validation callback
 function valid_date($str)
 {
 if(!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/',$str))
 {
 $this->form_validation->set_message('valid_date',
 'date format is not valid. yyyy-mm-dd');
 return false;
 }
 else
 {
 return true;
}
                
    }
}
